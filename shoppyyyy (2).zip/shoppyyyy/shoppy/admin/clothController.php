<?php

$name = $_POST['cloth_name'];

$price = $_POST['cloth_price'];

$desc = $_POST['cloth_description'];
$gender = $_POST['gender'];


$image = $_FILES['cloth_image']['name'];
$tmp_name = $_FILES['cloth_image']['tmp_name'];

if(move_uploaded_file($tmp_name,"assets/img/".$image)){
    echo "File uploaded successfully";
}else{
    echo " Error in file uploading";
}

// Database connection
include('connection.php');
$sql = "INSERT INTO items (item_name,item_price,item_desc,gender,item_image) VALUES ('$name','$price','$desc','$gender','$image')";
mysqli_query($conn,$sql) or die("Error in inserting");

mysqli_close($conn);
session_start();
$_SESSION['success'] = "Item added successfully.";
header("Location: index.php");

?>