﻿    <?php
    include('sidebar.php');
    ?>
            <div id="page-wrapper" >
                <div id="page-inner">
                    <div class="row">
                        <div class="col-md-12">
                        <h2>Add Item</h2>   
                        </div>
                    </div>
                    <!-- /. ROW  -->
                    <hr />
                <div class="row">
                    <div class="col-md-12">
                        <!-- Form Elements -->
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                Clothes Add Detail
                            </div>
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        
                                        <form role="form" method="post" action="clothController.php" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label>Clothes name</label>
                                                <input class="form-control" type="text" name="cloth_name"/>
                                               
                                            </div>

                                            <div class="form-group">
                                                <label>Clothes Price</label>
                                                <input class="form-control" type="number" name="cloth_price" placeholder="Rs.xxx"/>
                                               
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Choose Cloth Image</label>
                                                <input type="file" name="cloth_image"/>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label>
                                                <textarea class="form-control" rows="3" name="cloth_description"></textarea>
                                            </div>
                                
                                            <div class="form-group">
                                                <label>Gender</label>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="gender" id="optionsRadios1" value="Male"/>Male
                                                    </label>
                                                </div>
                                                <div class="radio">
                                                    <label>
                                                        <input type="radio" name="gender" id="optionsRadios2" value="Female"/>Female
                                                    </label>
                                                </div>
                                            </div>
                                            
                                           
                                            
                                            <button type="submit" class="btn btn-default">Submit Button</button>
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Form Elements -->
                    </div>
                </div>
                    <!-- /. ROW  -->
                    </div>
                    <?php
                    include('footer.php')
                ?>
