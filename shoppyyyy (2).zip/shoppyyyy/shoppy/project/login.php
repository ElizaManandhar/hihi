
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Animated Login & Registration Form | </title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800;900&display=swap');
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Poppins', sans-serif;
    }
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: lightslategray;
    }
    .wrapper {
      position: relative;
      width: 400px;
      height: 500px;
      background: #b49d86;
      box-shadow: 0 0 50px rgb(221, 226, 194);
      border-radius: 20px;
      padding: 40px;
      overflow: hidden;
    }
        .form-wrapper {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      transition: 1s ease-in-out;
    }
    .wrapper.active .form-wrapper.sign-in {
      transform: translateY(-450px);
    }
    .wrapper .form-wrapper.sign-up {
      position: absolute;
      top: 450px;
      left: 0;
    }
    .wrapper.active .form-wrapper.sign-up {
      transform: translateY(-450px);
    }
    h2 {
      font-size: 30px;
      color: #070505;
      text-align: center;
    }
    .input-group {
      position: relative;
      margin: 30px 0;
      border-bottom: 2px solid #1d1818;
    }
    .input-group label {
      position: absolute;
      top: 50%;
      left: 5px;
      transform: translateY(-50%);
      font-size: 16px;
      color: #0c0707;
      pointer-events: none;
      transition: .5s;
    }
    .input-group input {
      width: 320px;
      height: 40px;
      font-size: 16px;
      color: #0e0a0a;
      padding: 0 5px;
      background: transparent;
      border: none;
      outline: none;
    }
    .input-group input:focus~label,
    .input-group input:valid~label {
      top: -5px;
    }
    .remember {
      margin: -5px 0 15px 5px;
    }
    .remember label {
      color: #110f0f;
      font-size: 14px;
    }
    .remember label input {
      accent-color: #0ef;
    }
    button {
      position: relative;
      width: 100%;
      height: 40px;
      background: #0ef;
      box-shadow: 0 0 10px #0ef;
      font-size: 16px;
      color: #000;
      font-weight: 500;
      cursor: pointer;
      border-radius: 30px;
      border: none;
      outline: none;
    }
    .signUp-link {
      font-size: 14px;
      text-align: center;
      margin: 15px 0;
    }
    .signUp-link p {
      color: #141212;
    }
    .signUp-link p a {
      color: rgb(110, 4, 114);
      text-decoration: none;
      font-weight: 500;
    }
    .signUp-link p a:hover {
      text-decoration: underline;
    }
    
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="form-wrapper sign-in">
      <form method="post" action="register.php">
        <h2>Login</h2>
        <div class="input-group">
          <input type="text" name="sname" required>
          <label for="">Username</label>
        </div>
        <div class="input-group">
          <input type="password" name="spassword" required>
          <label for="">Password</label>
        </div>
        <div class="remember">
          <label><input type="checkbox"> Remember me</label>
        </div>
        <button type="submit" name="login">Login</button>
        <div class="signUp-link">
          <p>Don't have an account? <a href="#" class="signUpBtn-link">Register</a></p>
        </div>
      </form>
    </div>
    <div class="form-wrapper sign-up">
      <form method="post" action="register.php">
        <h2>Register</h2>
        <div class="input-group">
          <input type="text" name="sname" required>
          <label for="">Username</label>
        </div>
        <div class="input-group">
          <input type="email" name="semail" required>
          <label for="">Email</label>
        </div>
        <div class="input-group">
          <input type="password" name="spassword" required>
          <label for="">Password</label>
        </div>
        <div class="remember">
          <label><input type="checkbox"> I agree to the terms & conditions</label>
        </div>
        <button type="submit" name="register">Register</button>
        <div class="signUp-link">
          <p>Already have an account? <a href="#" class="signInBtn-link">Login</a></p>
        </div>
      </form>
    </div>
  </div>
  <script>
    const signInBtnLink = document.querySelector('.signInBtn-link');
    const signUpBtnLink = document.querySelector('.signUpBtn-link');
    const wrapper = document.querySelector('.wrapper');
    
    signUpBtnLink.addEventListener('click', () => {
        wrapper.classList.toggle('active');
    });
    
    signInBtnLink.addEventListener('click', () => {
        wrapper.classList.toggle('active');
    });
  </script>
</body>
</html>
