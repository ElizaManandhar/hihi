<?php
session_start();
include 'dbconnect.php'; // Your database connection file

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_id = $_POST['item_id'];
    $action = $_POST['action'];

    if ($action == 'add') {
        $check_query = "SELECT * FROM cart WHERE user_id = $user_id AND item_id = $item_id";
        $result = mysqli_query($conn, $check_query);

        if (mysqli_num_rows($result) > 0) {
            $update_query = "UPDATE cart SET quantity = quantity + 1 WHERE user_id = $user_id AND item_id = $item_id";
            mysqli_query($conn, $update_query);
        } else {
            $insert_query = "INSERT INTO cart (user_id, item_id, quantity) VALUES ($user_id, $item_id, 1)";
            mysqli_query($conn, $insert_query);
        }
    } elseif ($action == 'remove') {
        $delete_query = "DELETE FROM cart WHERE user_id = $user_id AND item_id = $item_id";
        mysqli_query($conn, $delete_query);
    }
}

$cart_query = "SELECT c.quantity, i.item_name, i.item_price, i.item_image 
               FROM cart c 
               JOIN items i ON c.item_id = i.item_id 
               WHERE c.user_id = $user_id";

$cart_items = mysqli_query($conn, $cart_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Cart</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <nav>
        <a href="index.html">Home</a>
        <a href="shop.html">Shop</a>
        <a href="cart.php">My Cart</a>
        <a href="logout.php">Logout</a>
    </nav>

    <div class="cart-container">
        <h2>My Cart</h2>
        <?php if (mysqli_num_rows($cart_items) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($cart_items)): ?>
                        <tr>
                            <td>
                                <img src="img/<?= $row['item_image']; ?>" alt="<?= $row['item_name']; ?>" width="50">
                                <?= $row['item_name']; ?>
                            </td>
                            <td>Rs <?= $row['item_price']; ?></td>
                            <td><?= $row['quantity']; ?></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="item_id" value="<?= $row['item_id']; ?>">
                                    <button type="submit" name="action" value="remove">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>
    </div>
</body>
</html>
