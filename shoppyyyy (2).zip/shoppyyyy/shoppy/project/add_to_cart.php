<?php
session_start();

// Check if the cart session exists, if not create it
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Get the product ID and quantity from the request
$product_id = isset($_POST['product_id']) ? $_POST['product_id'] : null;
$quantity = isset($_POST['quantity']) ? $_POST['quantity'] : 1;

// Validate the input
if ($product_id) {
    // Check if the product is already in the cart
    if (isset($_SESSION['cart'][$product_id])) {
        // Update the quantity
        $_SESSION['cart'][$product_id] += $quantity;
    } else {
        // Add the product to the cart
        $_SESSION['cart'][$product_id] = $quantity;
    }

    // Return a success response
    echo json_encode([
        'status' => 'success',
        'message' => 'Product added to cart successfully!',
        'cart' => $_SESSION['cart']
    ]);
} else {
    // Return an error response
    echo json_encode([
        'status' => 'error',
        'message' => 'Product ID is required.'
    ]);
}
?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('.add-to-cart').on('click', function(e) {
        e.preventDefault();

        var productId = $(this).data('product-id'); // Assuming you have a data attribute for product ID
        var quantity = 1; // You can modify this to get the quantity from an input field

        $.ajax({
            url: 'add_to_cart.php',
            type: 'POST',
            data: {
                product_id: productId,
                quantity: quantity
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    alert(response.message);
                    // Optionally update the cart display here
                } else {
                    alert(response.message);
                }
            },
            error: function() {
                alert('An error occurred while adding the product to the cart.');
            }
        });
    });
});
</script>