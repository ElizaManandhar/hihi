<?php
session_start();

if (!isset($_SESSION['loggedin'])) {
    header('Location: adminlogin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Admin Dashboard</title>
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <p>Welcome to the admin dashboard!</p>
        <p><a href="adminlogout.php">Logout</a></p>
    </div>
</body>
</html>