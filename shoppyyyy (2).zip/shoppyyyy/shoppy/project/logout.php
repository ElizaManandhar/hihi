<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Logout</title>
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background: lightslategray;
      font-family: 'Poppins', sans-serif;
    }
    .logout-wrapper {
      text-align: center;
      background: #b49d86;
      padding: 20px;
      border-radius: 20px;
      box-shadow: 0 0 50px rgb(221, 226, 194);
    }
    h2 {
      color: #070505;
    }
    button {
      background: #0ef;
      border: none;
      border-radius: 30px;
      padding: 10px 20px;
      font-size: 16px;
      cursor: pointer;
      box-shadow: 0 0 10px #0ef;
    }
  </style>
</head>
<body>
  <div class="logout-wrapper">
    <h2>Confirm Account Deletion</h2>
    <p>This action will permanently delete your account and all associated data.</p>
    <form method="post" action="delete_account.php">
      <button type="submit">Delete My Account</button>
    </form>
    <!-- <form method="post" action="login.php">
      <button type="submit">Cancel</button>
    </form> -->
  </div>
</body>
</html>